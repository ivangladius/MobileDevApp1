package de.fra_uas.fb2.mobiledevices.abeautifulmind

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var tvRadioButtonHint: TextView? = null
    private var tvNumberGames: TextView? = null
    private val tvNumberGamesPreText = "Number of games played: "
    private var tvUserScore: TextView? = null
    private var tvOpponentScore: TextView? = null

    private var randomRadioButton: RadioButton? = null
    private var greedyRadioButton: RadioButton? = null
    private var cautiousRadioButton: RadioButton? = null
    private var nashRadioButton: RadioButton? = null

    private var generateGame: Button? = null
    private var startOver: Button? = null

    private val gameData: GameData = GameData

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvNumberGames = findViewById(R.id.tvNumberGames)
        tvUserScore = findViewById(R.id.tvUserScore)
        tvOpponentScore = findViewById(R.id.tvOpponentScore)

        tvRadioButtonHint = findViewById(R.id.radioButtonHint)
        randomRadioButton = findViewById(R.id.radioRandom)
        greedyRadioButton = findViewById(R.id.radioGreedy)
        cautiousRadioButton = findViewById(R.id.radioCautious)
        nashRadioButton = findViewById(R.id.radioNash)

        generateGame = findViewById(R.id.buttonGenerateGame)
        startOver = findViewById(R.id.buttonStartOver)

        displayAllScores()

        generateGame!!.setOnClickListener(SubmitHandler())

        startOver!!.setOnClickListener {
            gameData.resetAll()
            displayAllScores()
        }
    }

    fun displayAllScores() {
        tvNumberGames!!.setText("$tvNumberGamesPreText ${gameData.gamesPlayed}")
        tvUserScore!!.setText("${gameData.playerScore}")
        tvOpponentScore!!.setText("${gameData.opponentScore}")
    }

    inner class SubmitHandler : View.OnClickListener {
        override fun onClick(v: View?) {
            var gameMode: String? = null

            if (randomRadioButton!!.isChecked)
                gameMode = "Random"
            else if (greedyRadioButton!!.isChecked)
                gameMode = "Greedy"
            else if (cautiousRadioButton!!.isChecked)
                gameMode = "Catious"
            else if (nashRadioButton!!.isChecked)
                gameMode = "Nash"

            val intent = Intent(this@MainActivity, GameActivity::class.java)
            intent.putExtra("mode", gameMode)
            startActivity(intent)
        }
    }
}
