package de.fra_uas.fb2.mobiledevices.abeautifulmind

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class GameActivity : AppCompatActivity() {

    private var gameMode: String? = null
    private var tvStrategy: TextView? = null

    private var buttonActionA: Button? = null
    private var buttonActionB: Button? = null
    private var buttonDismiss: Button? = null

    private val gameData: GameData = GameData

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        gameMode = getIntent().getStringExtra("mode")
        tvStrategy = findViewById(R.id.tvStrategy)

        buttonActionA = findViewById(R.id.buttonActionA)
        buttonActionB = findViewById(R.id.buttonActionB)
        buttonDismiss = findViewById(R.id.buttonDismiss)


        gameMode?.let {
            tvStrategy?.setText(it)
        }

        buttonActionA!!.setOnClickListener {
            gameData.win()
        }

        buttonActionB!!.setOnClickListener {
            gameData.lose()
        }

        buttonDismiss!!.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }
}