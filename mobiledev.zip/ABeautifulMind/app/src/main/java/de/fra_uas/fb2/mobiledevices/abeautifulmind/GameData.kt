package de.fra_uas.fb2.mobiledevices.abeautifulmind

object GameData {
    var gamesPlayed: Int = 0
    var playerScore: Int = 0
    var opponentScore: Int = 0

    fun win() {
        gamesPlayed++
        playerScore++
    }

    fun lose() {
        gamesPlayed++
        opponentScore++
    }

    fun resetAll() {
        gamesPlayed = 0
        playerScore = 0
        opponentScore = 0
    }
}

object MatrixBoard {
    var element00: String? = null
    var element01: String? = null
    var element10: String? = null
    var element11: String? = null
}



